"use strict";
var plugin = requirePlugin("chatRobot");
Component({
    properties: {
        msg: Object,
        recording: Boolean
    },
    data: {},
    lifetimes: {
        ready: function () {
        }
    },
    methods: {}
});
