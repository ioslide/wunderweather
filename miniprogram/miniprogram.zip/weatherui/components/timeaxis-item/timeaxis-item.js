Component({
  externalClasses: ['timeaxis-item-class'],
  options: {
    multipleSlots: true
  },
  properties: {

  },
  data: {
  },
  methods: {

  }
})
