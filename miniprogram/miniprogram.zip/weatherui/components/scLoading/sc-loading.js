"use strict";
Component({
  properties: {
    color: {
      type: String,
      value: "#3F51B5"
    },
    size: {
      type: String,
      value: "56"
    },
    width: {
      type: String,
      value: "6"
    }
  },
  externalClasses: ["sc-class"],
  data: {},
  methods: {}
});