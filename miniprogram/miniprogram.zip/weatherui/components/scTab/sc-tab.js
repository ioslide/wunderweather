"use strict";
Component({
  properties: {},
  data: {
    tabHeight: "auto"
  },
  relations: {
    "../scTabGroup/sc-tab-group": {
      type: "parent"
    }
  },
  methods: {}
});