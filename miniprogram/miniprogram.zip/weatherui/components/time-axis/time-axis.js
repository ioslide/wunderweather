Component({
  externalClasses: ['tui-timeaxis-class'],
  properties: {},
  data: {},
  methods: {}
})