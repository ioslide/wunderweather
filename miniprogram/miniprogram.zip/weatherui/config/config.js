"use strict";
Object.defineProperty(exports, "__esModule", {
  value: !0
});
exports.default = {
  weatherApiHost: "https://api.caiyunapp.com",
  weatherApiVersion: "v2.5",
  weatherApiToken: "F4i9DpgD0R1DIcPP", // yJgJQ31wdVX4RDrE  //Y2FpeXVuX25vdGlmeQ  //96Ly7wgKGq6FhllM
  radarApiToken:"Y2FpeXVuIGFuZHJpb2QgYXBp",
  radarApiVersion: "v1",
  // https://api.caiyunapp.com/v1/radar/fine_images?lat=31.473364419367254&lon=104.68616446943008&level=1&token=Y2FpeXVuIGFuZHJpb2QgYXBp
  // bingApiHost:"https://www.bingpic.com/api",
  bingApiHost:"https://cn.bing.com",
  cosApiHost:"https://weather.ioslide.com",
  // cloudEnv:"subweather-5hkjz",//订阅号
  // appid:'wx673e7d2fe4e6a413',  //订阅号
  // locationKey : 'V6KBZ-WDCED-HTR44-PHG7F-V2AME-B3FFO', //订阅号
  // subTemplateId:'3HGni7nX2GM6bmaKk-_Mldf-mPFCmhFYIpEWBksBmUI', // 订阅号
  // wxBassId:'c3d88ee29b2337915fd0', //订阅号
  wxBassId:'2973ccfe4956634d9d8a', //服务号
  cloudEnv:"wunderweather-nwepb", //服务号
  appid:'wx7b4bbc2d9c538e84', //服务号
  locationKey : 'BGZBZ-ZL63G-JUDQM-ILFCW-THIO2-K2B4D', //服务号
  subTemplateId:'4qBy3Pm6pqvOCP_RgX8MOhxYMwO36_YyxCkduHnsAbg', // 服务号
  gitHost:'https://github.com/ioslide/wunderweather.git',
  // gitHost:'https://git.weixin.qq.com/ioslide/weather.git',
  name: "XHY",
  description: ""
}
// https://tool.lu/timestamp/